# -*- encoding: utf-8 -*-
"""
@File       : main.py    
@Contact    : daihepeng@sina.cn
@Repository : https://github.com/phantomdai
@Modify Time: 2022/4/15 2:59 下午
@Author     : phantom
@Version    : 1.0
@Descriptions : 
"""
import argparse
parser = argparse.ArgumentParser(
description='Main function for generating seed queues using random, IB-SQ, and DFuzzer techniques for different datasets')
parser.add_argument('dataset', help="the name of dataset", choices=['MNIST', 'CIFAR10', 'ImageNet'])
parser.add_argument('data_dir', help="the dir that saves the original test cases", type=str)
parser.add_argument('size', help="the size of needed seed queue", type=int)
parser.add_argument('target_dir', help="the dir that saves the selected test cases", type=float)
parser.add_argument('seed_num', help="the number of the specified seed", type=int)
parser.add_argument('strategy', help="the technique that is usd to generate seed queue", choices=['random', 'IB-SQ', 'DFuzzer-IB', 'DFuzzer-FB'])
parser.add_argument('-z', '--zip_dir', help="the dir that saves the compressed images", type=str)
parser.add_argument('-c', '--candidate_set_size', help="the size of candidate set", default=10, type=int)
parser.add_argument('-t', '--threshold', help="the threshold that limits the number of comparison times between the candidate seeds and "
                                              "the seeds contained in the seed queue", default=10, type=int)
args = parser.parse_args()

if args.strategy == 'random':
    from random.random_SQ import *
    if args.dataset == 'ImageNet':
        generate_seed_queue_imagenet(args.data_dir, args.size, args.seed_num, args.target_dir)
    else:
        generate_seed_queue_mnist_cifar(args.dataset_name, args.data_dir, args.size, args.seed_num, args.target_dir)
elif args.strategy == 'IB-SQ':
    from ibsq.IB_SQ import *
    if args.dataset == 'ImageNet':
        information_based_method_imagenet(args.data_dir,args.zip_dir,args.target_dir, args.size, args.seed_num)
    else:
        information_based_method_mnist_cifar(args.dataset_name, args.data_dir, args.zip_dir, args.target_dir, args.size, args.seed_num)
elif args.strategy == 'DFuzzer-IB':
    from DFuzzer.dfuzzer import *
    if args.dataset == 'ImageNet':
        generate_seed_queue_imagenet(args.dataset_name, args.data_dir, args.size, "IBDM", args.seed_num)
    else:
        generate_seed_queue_mnist_cifar(args.dataset_name, args.data_dir, args.size, "FBDM", args.seed_num)