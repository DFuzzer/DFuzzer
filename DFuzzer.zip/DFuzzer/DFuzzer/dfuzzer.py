# -*- encoding: utf-8 -*-
"""
@File       : dfuzzer.py    
@Contact    : daihepeng@sina.cn
@Repository : https://github.com/phantomdai
@Modify Time: 2022/4/15 2:56 下午
@Author     : phantom
@Version    : 1.0
@Descriptions : 
"""

import os
import numpy as np
import random
import time
candidate_set_size = 10
threshold = 10
all_test_cases_size = {}

def decorator(fun):
    def wrapper(*args, **kwargs):
        start_time1 = time.clock()
        fun()
        print(time.clock() - start_time1)
    return wrapper


def initial_test_cases_size(dataset_name, matrix):
    if dataset_name == "MNIST" and matrix == "IBDM":
        zip_dir = "/Users/phantom/dataset/mnist/mnist_test_zip"
        all_test_cases = [os.path.join(zip_dir, img) for img in os.listdir(zip_dir) if img != '.DS_Store']
        for tc in all_test_cases:
            global all_test_cases_size
            all_test_cases_size[os.path.basename(tc).replace(".zip", "")] = os.path.getsize(tc)
    elif dataset_name == "CIFAR" and matrix == "IBDM":
        zip_dir = "/Users/phantom/dataset/cifar10/cifar_test_zip"
        all_test_cases = [os.path.join(zip_dir, img) for img in os.listdir(zip_dir) if img != '.DS_Store']
        for tc in all_test_cases:
            all_test_cases_size[os.path.basename(tc).replace(".zip", "")] = os.path.getsize(tc)
    elif dataset_name == "ImageNet" and matrix == "IBDM":
        zip_dir = "/Users/phantom/dataset/ImageNet/imagenet_test_zip"
        all_test_cases = [os.path.join(zip_dir, img) for img in os.listdir(zip_dir) if img != '.DS_Store']
        for tc in all_test_cases:
            all_test_cases_size[os.path.basename(tc).replace(".zip", "")] = os.path.getsize(tc)
    elif dataset_name == "MNIST" and matrix == "FBDM":
        for line in open('/Users/phantom/pythonDir/generateSQ/features/mnist', 'r').readlines():
            if line.strip() == "":
                continue
            else:
                all_test_cases_size[line.strip().split(":")[0]] = np.expand_dims(list(map(float, line.strip().split(":")[1].split(" "))), axis=0)
    elif dataset_name == "CIFAR" and matrix == "FBDM":
        for line in open('/Users/phantom/pythonDir/generateSQ/features/cifar', 'r').readlines():
            if line.strip() == "":
                continue
            else:
                all_test_cases_size[line.strip().split(":")[0]] = np.expand_dims(list(map(float, line.strip().split(":")[1].split(" "))), axis=0)
    elif dataset_name == "ImageNet" and matrix == "FBDM":
        for line in open('/Users/phantom/pythonDir/generateSQ/features/imagenet', 'r').readlines():
            if line.strip() == "":
                continue
            else:
                all_test_cases_size[line.strip().split(":")[0]] = np.expand_dims(list(map(float, line.strip().split(":")[1].split(" "))), axis=0)
    global initial_time


def measure_difference(candidate_set, seed_queue, matrix):
    selected_seed = ""
    max_distance = 0
    if len(seed_queue) > threshold:
        seed_queue = random.sample(seed_queue, threshold)
    if matrix == "IBDM":
        for seed in seed_queue:
            for candidate_seed in candidate_set:
                distance = abs(all_test_cases_size[seed] - all_test_cases_size[candidate_seed])
                if distance > max_distance:
                    max_distance = distance
                    selected_seed = candidate_seed
    else:
        for seed in seed_queue:
            f1 = all_test_cases_size[seed]
            for candidate_seed in candidate_set:
                f2 = all_test_cases_size[candidate_seed]
                # distance = np.linalg.norm(f1 - f2, ord=2)
                # cosin
                distance = np.sum(f1 * f2) / float(np.sqrt(np.sum(f2 * f2)) * np.sqrt(np.sum(f1 * f1)))
                if distance > max_distance:
                    max_distance = distance
                    selected_seed = candidate_seed
    return selected_seed


def generate_seed_queue_mnist_cifar(dataset_name, data_dir, size, matrix, seed_num):
    """
    generate seed queue for mnist and cifar
    :param dataset_name: mnist or cifar
    :param data_dir: the dir that includes the data
    :param size: the size of seed queue
    :param matrix: the matrix that measure the difference among the test cases
    :param seed_num: the seed number
    :return: selected seed
    """
    seed_queue = []
    if dataset_name == 'MNIST':
        distribution_pro = np.array([0.098, 0.1135, 0.1032, 0.101, 0.0982, 0.0892, 0.0958, 0.1028, 0.0974, 0.1009])
    else:
        distribution_pro = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])
    distribution_data = [round(x) for x in distribution_pro * size]
    random.seed(seed_num)
    for root, dirs, filenames in os.walk(data_dir):
        for dir in dirs:
            if dir == '.DS_store':
                continue
            category_seeds = [img for img in os.listdir(os.path.join(root, dir)) if img != '.DS_Store']
            category_selected_seeds = []
            while len(category_selected_seeds) < distribution_data[int(dir)]:
                candidate_set = random.sample(category_seeds, candidate_set_size)
                if len(seed_queue) == 0:
                    selected_seed = candidate_set[random.randint(0, candidate_set_size - 1)]
                    seed_queue.append(selected_seed)
                    category_selected_seeds.append(selected_seed)
                else:
                    selected_seed = measure_difference(candidate_set, seed_queue, matrix)
                    if selected_seed not in category_selected_seeds:
                        category_selected_seeds.append(selected_seed)

            seed_queue.extend(category_selected_seeds)
    return list(set(seed_queue))


def generate_seed_queue_imagenet(dataset_name, data_dir, size, matrix, seed_num):
    all_test_cases = [img for img in os.listdir(data_dir) if img != '.DS_Store']
    print("load all test cases")
    random.seed(seed_num)
    seed_queue = []
    print("get all features, and will select seeds")
    while len(seed_queue) < size:
        candidate_set = random.sample(all_test_cases, candidate_set_size)
        if len(seed_queue) == 0:
            seed_queue.append(candidate_set[random.randint(0, candidate_set_size - 1)])
        else:
            selected_seed = measure_difference(candidate_set, seed_queue, matrix)
            if selected_seed not in seed_queue:
                seed_queue.append(selected_seed)
            else:
                pass
    return seed_queue
