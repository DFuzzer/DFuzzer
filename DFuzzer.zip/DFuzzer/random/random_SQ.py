# -*- encoding: utf-8 -*-
"""
@File       : random_SQ.py    
@Contact    : daihepeng@sina.cn
@Repository : https://github.com/phantomdai
@Modify Time: 2022/4/15 2:55 下午
@Author     : phantom
@Version    : 1.0
@Descriptions : 
"""
import numpy as np
import os
import shutil
import logging
import time
logging.basicConfig(filename="./log.txt", level=logging.INFO)


def generate_seed_queue_mnist_cifar(dataset_name, data_dir, size, seed_num, target_dir):
    """
    generate the specific size of seed queue (note that this function is can
    be used for constructing seed queue for cifar10)
    :param dataset_name: the name of dataset
    :param data_dir: the dir that saves all test cases
    :param size: the size of seed queue
    :param seed_num: the seed of random object
    :param target_dir: the dir that saves the generated seeds
    :return: the generated seed queue
    """
    np.random.seed(seed_num)
    if dataset_name == 'MNIST':
        distribution_pro = np.array([0.098, 0.1135, 0.1032, 0.101, 0.0982, 0.0892, 0.0958, 0.1028, 0.0974, 0.1009])
    else:
        distribution_pro = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])
    distribution_data = [round(x) for x in distribution_pro * size]
    print("the distribution of data is " + str(distribution_data))
    print("the sum of distribution is " + str(np.sum(distribution_data)))

    selected_test_cases = []
    for root, dirs, filenames in os.walk(data_dir):
        for dir in dirs:
            if dir == '.DS_store':
                continue
            category_dir = os.path.join(root, dir)
            category_data = [os.path.join(category_dir, img_name)
                             for img_name in os.listdir(category_dir) if img_name != '.DS_store']
            print('the index is ' + str(dir) + ' and the size is ' + str(distribution_data[int(dir)]))
            selected_test_cases.extend(np.random.choice(category_data, distribution_data[int(dir)], replace=False))
    if os.path.exists(os.path.join(target_dir, str(seed_num))):
        os.rmdir(os.path.join(target_dir, str(seed_num)))
        os.mkdir(os.path.join(target_dir, str(seed_num)))
    else:
        new_dir = os.path.join(target_dir, str(seed_num))
        print('create a new dir: ' + new_dir)
        os.mkdir(new_dir)
    for seed in selected_test_cases:
        shutil.copy(seed, os.path.join(os.path.join(target_dir, str(seed_num)), os.path.basename(seed)))


def generate_seed_queue_imagenet(data_dir, size, seed_num, target_dir):
    """
    generate the specific size of seed queue
    :param data_dir: the dir that saves all test cases
    :param size: the size of seed queue
    :param seed_num: the seed of random object
    :param target_dir: the dir that saves the generated seeds
    :return: the generated seed queue
    """
    np.random.seed(seed_num)
    all_test_cases = [os.path.join(data_dir, img) for img in os.listdir(data_dir) if img != '.DS_Store']
    selected_test_cases = np.random.choice(all_test_cases, size, replace=False)
    if os.path.exists(os.path.join(target_dir, str(seed_num))):
        shutil.rmtree(os.path.join(target_dir, str(seed_num)))
        os.mkdir(os.path.join(target_dir, str(seed_num)))
    else:
        new_dir = os.path.join(target_dir, str(seed_num))
        print('create a new dir: ' + new_dir)
        os.mkdir(new_dir)
    for seed in selected_test_cases:
        shutil.copy(seed, os.path.join(os.path.join(target_dir, str(seed_num)), os.path.basename(seed)))
