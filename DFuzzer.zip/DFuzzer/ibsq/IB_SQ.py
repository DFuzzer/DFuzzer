from utils.huffman_coding import *
import numpy as np
import os
import shutil


def information_based_method_mnist_cifar(dataset_name, data_dir, zip_dir, target_dir, size, seed_num):
    """
    constructing seed queue using TSDm
    :param dataset_name: the name of dataset
    :param data_dir: the dir that saves the imgs
    :param zip_dir: the dir that saves the compressed imgs
    :param target_dir: the dir that saves the compressed imgs
    :param size: the size of seed queue
    :param seed_num: the seed number
    :return: the generated seed queue
    """
    if dataset_name == 'MNIST':
        distribution_pro = np.array([0.098, 0.1135, 0.1032, 0.101, 0.0982, 0.0892, 0.0958, 0.1028, 0.0974, 0.1009])
    else:
        distribution_pro = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])
    distribution_data = [round(x) for x in distribution_pro * size]
    print("the distribution of data is " + str(distribution_data))
    print("the sum of distribution is " + str(np.sum(distribution_data)))

    generated_seed_queue = []
    for root, dirs, filenames in os.walk(data_dir):
        for dir in dirs:
            if dir == '.DS_store':
                continue
            category_dir = os.path.join(root, dir)
            category_seeds = [os.path.join(category_dir, img) for img in os.listdir(category_dir) if img != '.DS_Store']
            category_seeds_size = {}
            for category_seed in category_seeds:
                compress(category_seed, os.path.join(zip_dir, os.path.basename(category_seed) + '.zip'))
                category_seeds_size[category_seed] = os.path.getsize(os.path.join(zip_dir, os.path.basename(category_seed) + '.zip'))
            category_seeds_size = np.array(sorted(category_seeds_size.items(), key=lambda x: x[1], reverse=True))[:distribution_data[int(dir)]]
            print('the distribution of category ' + dir + ' is ' + str(distribution_data[int(dir)]) + '; the real number of seeds is ' + str(len(category_seeds_size)))
            generated_seed_queue.extend([tc[0] for tc in category_seeds_size])
            print('the length of seed queue is ' + str(len(generated_seed_queue)))

    if os.path.exists(os.path.join(target_dir, str(seed_num))):
        os.rmdir(os.path.join(target_dir, str(seed_num)))
        os.mkdir(os.path.join(target_dir, str(seed_num)))
    else:
        new_dir = os.path.join(target_dir, str(seed_num))
        print('create a new dir: ' + new_dir)
        os.mkdir(new_dir)
    for seed in generated_seed_queue:
        shutil.copy(seed, os.path.join(os.path.join(target_dir, str(seed_num)), os.path.basename(seed)))


def information_based_method_imagenet(data_dir, zip_dir, target_dir, size, seed_num):
    """
        constructing seed queue using TSDm for ImageNet
        :param data_dir: the dir that saves the imgs
        :param zip_dir: the dir that saves the compressed imgs
        :param target_dir: the dir that saves the compressed imgs
        :param size: the size of seed queue
        :param seed_num: the seed number
        :return: the generated seed queue
    """
    all_test_cases = [os.path.join(data_dir, img) for img in os.listdir(data_dir) if img != '.DS_Store']
    print("get all data")
    all_test_cases_size = {}
    for tc in all_test_cases:
        compress(tc, os.path.join(zip_dir, os.path.basename(tc) + '.zip'))
        all_test_cases_size[tc] = os.path.getsize(
            os.path.join(zip_dir, os.path.basename(tc) + '.zip'))
    print("compress all test cases and calculate the lengths")
    generated_seed_queue = [tc[0] for tc in np.array(sorted(all_test_cases_size.items(), key=lambda x:x[1], reverse=True))[:size]]

    if os.path.exists(os.path.join(target_dir, str(seed_num))):
        os.rmdir(os.path.join(target_dir, str(seed_num)))
        os.mkdir(os.path.join(target_dir, str(seed_num)))
    else:
        new_dir = os.path.join(target_dir, str(seed_num))
        print('create a new dir: ' + new_dir)
        os.mkdir(new_dir)
    for seed in generated_seed_queue:
        shutil.copy(seed, os.path.join(os.path.join(target_dir, str(seed_num)), os.path.basename(seed)))
